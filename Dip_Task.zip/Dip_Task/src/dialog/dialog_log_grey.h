#ifndef DIALOG_LOG_GREY_H
#define DIALOG_LOG_GREY_H

#include <QDialog>
#include <QtMath>


//对数灰度变换界面类
namespace Ui {
class DialogLogGrey;
}

class DialogLogGrey : public QDialog
{
    Q_OBJECT

public:
    explicit DialogLogGrey(QWidget *parent = 0);
    ~DialogLogGrey();

private:
    Ui::DialogLogGrey *ui;

    void paintFunctionImage(double __a, double __b);

signals:
    void sendData(double a, double b);
private slots:
    void on_buttonBox_accepted();           //确认按钮信号槽函数
    void on_aDoubleSpinBox_valueChanged(double arg1);   //设置a值槽函数
    void on_bDoubleSpinBox_valueChanged(double arg1);    // //设置b值槽函数
};

#endif // DIALOG_LOG_GREY_H
