#include "dialog_exp_transform.h"
#include "ui_dialog_exp_transform.h"

DialogExpTransform::DialogExpTransform(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogExpTransform)
{
    ui->setupUi(this);     //初始化界面变量

    paintFunctionImage(ui->bDoubleSpinBox->value(), ui->cDoubleSpinBox->value(), ui->aDoubleSpinBox->value());     //界面传值
}

DialogExpTransform::~DialogExpTransform()
{
    delete ui;          //析构掉ui变量，释放内存
}

void DialogExpTransform::on_buttonBox_accepted()
{
    emit sendData(ui->bDoubleSpinBox->value(), ui->cDoubleSpinBox->value(), ui->aDoubleSpinBox->value());      //槽函数用于触发设置的指数变换值a,b,c

}

void DialogExpTransform::paintFunctionImage(double b, double c, double a)
{
    // generate some data:
    QVector<double> x(1001), y(1001); // 以 0..100入口初始化
    for (int i=0; i<1001; ++i)
    {
      x[i] = i/50.0 - 10;
      y[i] = qPow(b, c*(x[i]-a));
    }
    // 创建图并赋值给它:
    ui->customPlot->addGraph();
    ui->customPlot->graph(0)->setData(x, y);
    // 给轴一些 labels:
    ui->customPlot->xAxis->setLabel("x");
    ui->customPlot->yAxis->setLabel("y");
    // 设定轴的范围, 便于可视化数据:
    ui->customPlot->xAxis->setRange(-10, 10);
    ui->customPlot->yAxis->setRange(-10, 10);
    ui->customPlot->replot();
}
    //用于b值的修改
void DialogExpTransform::on_bDoubleSpinBox_valueChanged(double arg1)
{
    paintFunctionImage(arg1, ui->cDoubleSpinBox->value(), ui->aDoubleSpinBox->value());
}
   //用于c值的修改
void DialogExpTransform::on_cDoubleSpinBox_valueChanged(double arg1)
{
    paintFunctionImage(ui->bDoubleSpinBox->value(), arg1, ui->aDoubleSpinBox->value());
}
   //用于a值的修改
void DialogExpTransform::on_aDoubleSpinBox_valueChanged(double arg1)
{
    paintFunctionImage(ui->bDoubleSpinBox->value(), ui->cDoubleSpinBox->value(), arg1);
}
