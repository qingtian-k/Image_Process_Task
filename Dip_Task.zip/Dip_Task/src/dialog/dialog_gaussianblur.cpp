#include "dialog_gaussianblur.h"
#include "ui_gaussianblurdialog.h"

GaussianBlurDialog::GaussianBlurDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::GaussianBlurDialog)
{
    ui->setupUi(this);        //初始化界面
}

GaussianBlurDialog::~GaussianBlurDialog()
{
    delete ui;         //析构界面变量
}

void GaussianBlurDialog::on_buttonBox_accepted()
{
    emit sendData(ui->radiusSpinBox->value(), ui->sigmaSpinBox->value());       //设定完模糊半径和sigma值后按钮提交
}

