#ifndef DIALOG_THRESHOLD_TRANSFORM_H
#define DIALOG_THRESHOLD_TRANSFORM_H

#include <QDialog>


//双阈值灰度变换的界面头文件，对应源文件在dialog_two_threshold_transform.cpp里
namespace Ui {
class DialogThresholdTransform;
}

class DialogThresholdTransform : public QDialog
{
    Q_OBJECT

public:
    explicit DialogThresholdTransform(QWidget *parent = 0);
    ~DialogThresholdTransform();

private:
    Ui::DialogThresholdTransform *ui;

    void paintFunctionImage(int t1, int t2, int option);

signals:                                            //信号槽
    void sendData(int t1, int t2, int opt);

private slots:                                    //设置值的槽函数
    void on_buttonBox_accepted();
    void on_T1SpinBox_valueChanged(int arg1);
    void on_T2SpinBox_valueChanged(int arg1);
    void on_comboBox_currentIndexChanged(int index);
};

#endif // DIALOG_THRESHOLD_TRANSFORM_H
