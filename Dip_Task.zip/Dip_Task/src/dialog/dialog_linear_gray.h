#ifndef DIALOG_LINEAR_GRAY_H
#define DIALOG_LINEAR_GRAY_H

#include <QDialog>
#include <QPixmap>
#include <QVector>

namespace Ui {
class LinearGrayDialog;
}

   //声明线性变换对话框的类，对应定义在源文件Source里的dialog_linear_gray.cpp里
class LinearGrayDialog : public QDialog
{
    Q_OBJECT

public:
    explicit LinearGrayDialog(QWidget *parent = nullptr);    //构造函数
    ~LinearGrayDialog();

private:
    Ui::LinearGrayDialog *ui;        //界面私有变量

    void paintFunctionImage(double _a, double _b);

signals:
    void sendData(double a, double b);
private slots:
    void on_buttonBox_accepted();     //声明按钮槽函数，用于提交设定的a和b值
    void on_aDoubleSpinBox_valueChanged(double arg1);    //更改a值槽函数
    void on_bDoubleSpinBox_valueChanged(double arg1);    //更改b值槽函数
};

#endif // DIALOG_LINEAR_GRAY_H
