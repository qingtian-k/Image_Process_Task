#ifndef DIALOG_EXP_TRANSFORM_H
#define DIALOG_EXP_TRANSFORM_H

#include <QDialog>


//指数线性变换函数的声明，具体定义在Souruce源文件里的dialog_exp_transform.cpp文件里
namespace Ui {
class DialogExpTransform;
}

class DialogExpTransform : public QDialog
{
    Q_OBJECT

public:
    explicit DialogExpTransform(QWidget *parent = nullptr);      //构造函数
    ~DialogExpTransform();                              //析构函数

private:
    Ui::DialogExpTransform *ui;           //界面私有变量，注意界面类为Ui

    void paintFunctionImage(double b, double c, double a);

signals:
    void sendData(double, double, double);
private slots:
    void on_buttonBox_accepted();                           //接受按钮槽
    void on_bDoubleSpinBox_valueChanged(double arg1);       //设置数b的槽
    void on_cDoubleSpinBox_valueChanged(double arg1);       //设置数c的槽
    void on_aDoubleSpinBox_valueChanged(double arg1);       //设置数a的槽
};

#endif // DIALOG_EXP_TRANSFORM_H
