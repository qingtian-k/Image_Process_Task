#ifndef GAUSSIANBLURDIALOG_H
#define GAUSSIANBLURDIALOG_H

#include <QDialog>

namespace Ui {
class GaussianBlurDialog;
}
     //这里声明高斯模糊对话框的头文件，对应定义在Source源文件dialog_gaussianblur.cpp里，高斯模糊的实现在源文件utils.gaussianblur.cpp
class GaussianBlurDialog : public QDialog
{
    Q_OBJECT

public:
    explicit GaussianBlurDialog(QWidget *parent = 0);    //构造函数
    ~GaussianBlurDialog();                               //析构函数

private:
    Ui::GaussianBlurDialog *ui;            //界面类私有变量

signals:
    void sendData(int, double);           //信号槽函数

private slots:
    void on_buttonBox_accepted();        //信号槽按钮函数
};

#endif // GAUSSIANBLURDIALOG_H
