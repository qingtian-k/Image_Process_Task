#include "mainwindow.h"
#include <QApplication>


//主函数，分别初始化窗体变量进而应用变量
int main(int argc, char *argv[])
{

    QApplication a(argc, argv);
    MainWindow w;
    w.show();
    return a.exec();
}
