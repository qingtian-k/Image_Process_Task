﻿#include "tools.h"
#include "medianfilter.h"

#define min2(a,b) (a)<(b)?(a):(a)
#define min(a,b,c) (min2(a,b))<(c)?(min2(a,b)):(c)

//这里定义一些图像处理的具体函数，自己参照网上添加了部分功能
/*****************************************************************************
 *                           Greyscale
 * **************************************************************************/
QImage Tools::GreyScale(QImage origin)
{
    QImage *newImage = new QImage(origin.width(), origin.height(),
                                   QImage::Format_ARGB32);
    QColor oldColor;

    for (int x=0; x<newImage->width(); x++) {
        for (int y=0; y<newImage->height(); y++) {
            oldColor = QColor(origin.pixel(x,y));      //获取源图像的三通道的值
            int average = (oldColor.red()*299+oldColor.green()*587+oldColor.blue()*114+500)/1000;  //分别取各通道值不同权重的均值
            newImage->setPixel(x,y,qRgb(average,average,average));  //灰度化
        }
    }

    return *newImage;

}

/*************************************************************************************
 *                           Adjust color temperature（Adjust different r,g,b value）
 * ***********************************************************************************/
QImage Tools::Warm(int delta, QImage origin)
{
    QImage *newImage = new QImage(origin.width(), origin.height(),
                                  QImage::Format_ARGB32);

    QColor oldColor;
    int r, g, b;

    for (int x=0; x<newImage->width(); x++)
    {
        for (int y=0; y<newImage->height(); y++)
        {
            oldColor = QColor(origin.pixel(x,y));

            r = oldColor.red() + delta;           //red and green value should biger,blue is constant
            g = oldColor.green() + delta;
            b = oldColor.blue();
//            qDebug()<<r<<" "<<g<<""<<b;

            // Check if the new values are between 0 and 255
            r = qBound(0, r, 255);
            g = qBound(0, g, 255);

            newImage->setPixel(x,y, qRgb(r,g,b));
        }
    }
    return *newImage;
}

QImage Tools::Cool(int delta, QImage origin)
{
    QImage *newImage = new QImage(origin.width(), origin.height(),
                                  QImage::Format_ARGB32);

    QColor oldColor;
    int r, g, b;

    for (int x=0; x<newImage->width(); x++)
    {
        for (int y=0; y<newImage->height(); y++)
        {
            oldColor = QColor(origin.pixel(x,y));

            r = oldColor.red();            //Add blue value
            g = oldColor.green();
            b = oldColor.blue() + delta;

            // Check if the new values are between 0 and 255
            r = qBound(0, r, 255);
            g = qBound(0, g, 255);

            newImage->setPixel(x,y, qRgb(r,g,b));
        }
    }
    return *newImage;
}



/*****************************************************************************
 *                          Adjust image brightness
 * **************************************************************************/
QImage Tools::Brightness(int delta, QImage origin)
{
    QImage *newImage = new QImage(origin.width(), origin.height(),
                                  QImage::Format_ARGB32);

    QColor oldColor;
    int r, g, b;

    for (int x=0; x<newImage->width(); x++)
    {
        for (int y=0; y<newImage->height(); y++)
        {
            oldColor = QColor(origin.pixel(x,y));

            r = oldColor.red() + delta;         //Add the value of r,g,b
            g = oldColor.green() + delta;
            b = oldColor.blue() + delta;

            // Check if the new values are between 0 and 255
            r = qBound(0, r, 255);
            g = qBound(0, g, 255);
            b = qBound(0, b, 255);

            newImage->setPixel(x,y, qRgb(r,g,b));
        }
    }
    return *newImage;
}

/*****************************************************************************
 *                                   Flip
 * **************************************************************************/
QImage Tools::Horizontal(const QImage &origin)
{
    QImage *newImage = new QImage(QSize(origin.width(), origin.height()),
                                  QImage::Format_ARGB32);
    QColor tmpColor;
    int r, g, b;
    for (int x=0; x<newImage->width(); x++)
    {
        for (int y=0; y<newImage->height(); y++)
        {
            tmpColor = QColor(origin.pixel(x, y));
            r = tmpColor.red();
            g = tmpColor.green();
            b = tmpColor.blue();

            newImage->setPixel(newImage->width()-x-1,y, qRgb(r,g,b));   //Exchange the horizontal poisition value

        }
    }
    return *newImage;
}

QImage Tools::Vertical(const QImage &origin)
{
    QImage *newImage = new QImage(QSize(origin.width(), origin.height()),
                                  QImage::Format_ARGB32);
    QColor tmpColor;
    int r, g, b;
    for (int x=0; x<newImage->width(); x++)
    {
        for (int y=0; y<newImage->height(); y++)
        {
            tmpColor = QColor(origin.pixel(x, y));
            r = tmpColor.red();
            g = tmpColor.green();
            b = tmpColor.blue();

            newImage->setPixel(x, newImage->height()-y-1, qRgb(r,g,b));     //Exchange the vertical poisition value

        }
    }
    return *newImage;
}





/*****************************************************************************
 *                            添加相框
 * **************************************************************************/
QImage Tools::DrawFrame(QImage origin, QImage &frame)
{
    QImage *newImage = new QImage(origin);
    QPainter painter;

    int width = origin.width();
    int height = origin.height();

    QImage tmpFrame = frame.scaled(QSize(width, height));   //Resize the scale as origin's

    painter.begin(newImage);
    painter.drawImage(0, 0, tmpFrame);     //Add Frame pixel to original
    painter.end();

    return *newImage;

}

/*****************************************************************************
 *                           线性灰度变换 y = ax + b
 * **************************************************************************/
QImage Tools::LinearLevelTransformation(const QImage &origin, double _a, double _b)
{
    QImage *newImage = new QImage(origin.width(), origin.height(),
                                   QImage::Format_ARGB32);
    QColor oldColor;
    int grayLevel = 0;

    for (int x=0; x<newImage->width(); x++) {
        for (int y=0; y<newImage->height(); y++) {
            oldColor = QColor(origin.pixel(x,y));
            grayLevel = (oldColor.red()*299+oldColor.green()*587+oldColor.blue()*114+500)/1000;    //对应灰度值
            int _y = _a*grayLevel + _b;
            // Make sure that the new values are between 0 and 255
            _y = qBound(0, _y, 255);

            newImage->setPixel(x,y,qRgb(_y,_y,_y));
        }
    }
//    qDebug()<<"a:"<<_a<<"\tb:"<<_b;

    return *newImage;
}


/*****************************************************************************
 *                           对数灰度变换
 * **************************************************************************/
QImage Tools::LogGreyLevelTransformation(const QImage &origin, double a, double b)
{
    QImage *newImage = new QImage(origin.width(), origin.height(),
                                   QImage::Format_ARGB32);
    QColor oldColor;
    int grayLevel = 0;

    for (int x=0; x<newImage->width(); x++) {
        for (int y=0; y<newImage->height(); y++) {
            oldColor = QColor(origin.pixel(x,y));
            grayLevel = (oldColor.red()*299+oldColor.green()*587+oldColor.blue()*114+500)/1000;   //和上面一样，各通道权值不一样
            int _y = qLn(b+grayLevel)/qLn(a);

            // Make sure that the new values are between 0 and 255
            _y = qBound(0, _y, 255);

            newImage->setPixel(x,y,qRgb(_y,_y,_y));
        }
    }

    return *newImage;
}


/*****************************************************************************
 *                           幂次灰度变换 _y=c*_x^r+b
 * **************************************************************************/
QImage Tools::PowerGreyLevelTransformation(const QImage &origin, double c, double r, double b)
{
    QImage *newImage = new QImage(origin.width(), origin.height(),
                                   QImage::Format_ARGB32);
    QColor oldColor;
    int _x = 0;

    for (int x=0; x<newImage->width(); x++) {
        for (int y=0; y<newImage->height(); y++) {
            oldColor = QColor(origin.pixel(x,y));
            _x = (oldColor.red()*299+oldColor.green()*587+oldColor.blue()*114+500)/1000;
            int _y =c*qPow(_x, r)+b;

            // Make sure that the new values are between 0 and 255
            _y = qBound(0, _y, 255);

            newImage->setPixel(x,y,qRgb(_y,_y,_y));
        }
    }

    return *newImage;
}


/*****************************************************************************
 *                                  指数灰度变换
 * **************************************************************************/
QImage Tools::ExpTransform(const QImage &origin, double b, double c, double a)
{
    QImage *newImage = new QImage(origin.width(), origin.height(),
                                   QImage::Format_ARGB32);
    QColor oldColor;
    int _x = 0;

    for (int x=0; x<newImage->width(); x++) {
        for (int y=0; y<newImage->height(); y++) {
            oldColor = QColor(origin.pixel(x,y));
            _x = (oldColor.red()*299+oldColor.green()*587+oldColor.blue()*114+500)/1000;
            int _y =qPow(b, c*(_x-a));

            // Make sure that the new values are between 0 and 255
            _y = qBound(0, _y, 255);

            newImage->setPixel(x,y,qRgb(_y,_y,_y));
        }
    }

    return *newImage;
}

/*****************************************************************************
 *                                  双阈值灰度变换
 * int option:
 *          0   0-255-0
 *          1   255-0-255
 * **************************************************************************/
QImage Tools::TwoThreshold(const QImage &origin, double t1, double t2, int option)    //t1和t2分别为对应阈值
{
    QImage *newImage = new QImage(origin.width(), origin.height(),
                                   QImage::Format_ARGB32);
    QColor oldColor;
    int _x = 0;
    int _y = 0;
    if (option == 0)
    {
        for (int x=0; x<newImage->width(); x++) {
            for (int y=0; y<newImage->height(); y++) {
                oldColor = QColor(origin.pixel(x,y));
                _x = (oldColor.red()*299+oldColor.green()*587+oldColor.blue()*114+500)/1000;

                if (_x < t1 || _x > t2)     //Whether exceed the threshold
                    _y = 0;
                else
                    _y = 255;


                // Make sure that the new values are between 0 and 255
                _y = qBound(0, _y, 255);

                newImage->setPixel(x,y,qRgb(_y,_y,_y));
            }
        }
    }
    else                                   //第二种阈值法
    {
        for (int x=0; x<newImage->width(); x++) {
            for (int y=0; y<newImage->height(); y++) {
                oldColor = QColor(origin.pixel(x,y));
                _x = (oldColor.red()*299+oldColor.green()*587+oldColor.blue()*114+500)/1000;

                if (_x>=t1 && _x<=t2)
                    _y = 0;
                else
                    _y = 255;


                // Make sure that the new values are between 0 and 255
                _y = qBound(0, _y, 255);

                newImage->setPixel(x,y,qRgb(_y,_y,_y));
            }
        }
    }

    return *newImage;
}



/*****************************************************************************
 *                                拉伸灰度变换
 * 拉伸变换使用一个分段函数，三个k值
 * **************************************************************************/
QImage Tools::StretchTransform(const QImage &origin,
                               int x1, int x2,
                               double k1, double k2, double k3,
                               double b2, double b3)
{
    QImage *newImage = new QImage(origin.width(), origin.height(),
                                   QImage::Format_ARGB32);
    QColor oldColor;
    int _x = 0;
    int _y = 0;

    for (int x=0; x<newImage->width(); x++) {
        for (int y=0; y<newImage->height(); y++) {
            oldColor = QColor(origin.pixel(x,y));
            _x = (oldColor.red()*299+oldColor.green()*587+oldColor.blue()*114+500)/1000;

            if ( _x<x1)                             //第一分段
                _y = k1*_x;
            else if (_x < x2)                     //第二分段
                _y = k2*_x + b2;
            else
                _y = k3*_x + b3;                   //第三分段


            // Make sure that the new values are between 0 and 255
            _y = qBound(0, _y, 255);

            newImage->setPixel(x,y,qRgb(_y,_y,_y));
        }
    }

    return *newImage;
}


/*****************************************************************************
 *                               简单平滑处理
 * **************************************************************************/
QImage Tools::SimpleSmooth(const QImage &origin)
{
    QImage *newImage = new QImage(origin);

    int kernel[5][5] = {                //卷积核
        {0,0,1,0,0},
        {0,1,3,1,0},
        {1,3,7,3,1},
        {0,1,3,1,0},
        {0,0,1,0,0}
    };
    int kernelSize = 5;
    int sumKernel=27;
    int r,g,b;
    QColor color;

    for(int x=kernelSize/2; x<newImage->width()-kernelSize/2; x++)
    {
        for (int y=kernelSize/2; y<newImage->height()-kernelSize/2; y++)
        {
            r = g = b = 0;
            for (int i=-kernelSize/2; i<=kernelSize/2; i++)
            {
                for (int j=-kernelSize/2; j<=kernelSize/2; j++)
                {
                    color = QColor(origin.pixel(x+i,y+j));
                    r += color.red()*kernel[kernelSize/2+i][kernelSize/2+j];
                    g += color.green()*kernel[kernelSize/2+i][kernelSize/2+j];
                    b += color.blue()*kernel[kernelSize/2+i][kernelSize/2+j];

                }
            }
            r = qBound(0, r/sumKernel, 255);
            g = qBound(0, g/sumKernel, 255);
            b = qBound(0, b/sumKernel, 255);

            newImage->setPixel(x,y,qRgb(r,g,b));

        }
    }
    return *newImage;
}


/*****************************************************************************
 *                                   中值滤波
 * **************************************************************************/
QImage Tools::MeidaFilter(const QImage &origin, int filterRadius)
{
    int imageHeight = origin.height();
    int imageWidth = origin.width();
    MedianFilter medianFilter;
    int* resImageBits = new int[imageHeight * imageWidth];
    medianFilter.applyMedianFilter((int*)origin.bits(), resImageBits, imageHeight, imageWidth, filterRadius);    //这里直接调用MedianFilter类的applyMedianFilter方法

    QImage destImage((uchar*)resImageBits, imageWidth, imageHeight, origin.format());   //必须将图像化为uchar类型
//    QPixmap pixRes;
//    pixRes.convertFromImage(destImage);


    return destImage;
}


/*****************************************************************************
 *                                   拉普拉斯锐化
 * **************************************************************************/
QImage Tools::LaplaceSharpen(const QImage &origin)
{

    int width = origin.width();
    int height = origin.height();
    QImage newImage = QImage(width, height,QImage::Format_RGB888);
    int window[3][3] = {0,-1,0,-1,4,-1,0,-1,0};           //拉普拉斯算子，这里只取四邻域

    for (int x=1; x<width; x++)
    {
        for(int y=1; y<height; y++)
        {
            int sumR = 0;
            int sumG = 0;
            int sumB = 0;

            //对每一个像素使用模板

            for(int m=x-1; m<= x+1; m++)
                for(int n=y-1; n<=y+1; n++)
                {
                    if(m>=0 && m<width && n<height)
                    {
                        sumR += QColor(origin.pixel(m,n)).red()*window[n-y+1][m-x+1];
                        sumG += QColor(origin.pixel(m,n)).green()*window[n-y+1][m-x+1];
                        sumB += QColor(origin.pixel(m,n)).blue()*window[n-y+1][m-x+1];
                    }
                }


            int old_r = QColor(origin.pixel(x,y)).red();
            sumR += old_r;
            sumR = qBound(0, sumR, 255);

            int old_g = QColor(origin.pixel(x,y)).green();
            sumG += old_g;
            sumG = qBound(0, sumG, 255);

            int old_b = QColor(origin.pixel(x,y)).blue();
            sumB += old_b;
            sumB = qBound(0, sumB, 255);


            newImage.setPixel(x,y, qRgb(sumR, sumG, sumB));      //新图像赋值R,G,B值
        }
    }

    return newImage;

}

/*****************************************************************************
 *                              Sobel Edge Detector
 * **************************************************************************/
QImage Tools::SobelEdge(const QImage &origin)
{
    double *Gx = new double[9];
    double *Gy = new double[9];

    /* Sobel */
    Gx[0] = 1.0; Gx[1] = 0.0; Gx[2] = -1.0;
    Gx[3] = 2.0; Gx[4] = 0.0; Gx[5] = -2.0;
    Gx[6] = 1.0; Gx[7] = 0.0; Gx[8] = -1.0;

    Gy[0] = -1.0; Gy[1] = -2.0; Gy[2] = - 1.0;
    Gy[3] = 0.0; Gy[4] = 0.0; Gy[5] = 0.0;
    Gy[6] = 1.0; Gy[7] = 2.0; Gy[8] = 1.0;

    QRgb pixel;
    QImage grayImage = GreyScale(origin);
    int height = grayImage.height();
    int width = grayImage.width();
    QImage newImage = QImage(width, height,QImage::Format_RGB888);

    /* 改写下面这行解决：某些编译器下不支持“变长数组”的问题 */
    // float sobel_norm[width*height];


    float *sobel_norm = new float[width * height];
    float max = 0.0;
    QColor my_color;

    for (int x=0; x<width; x++)
    {
        for( int y=0; y<height; y++)
        {
            double value_gx = 0.0;
            double value_gy = 0.0;

            for (int k=0; k<3;k++)
            {
                for(int p=0; p<3; p++)
                {
                    pixel=grayImage.pixel(x+1+1-k,y+1+1-p);
                    value_gx += Gx[p*3+k] * qRed(pixel);
                    value_gy += Gy[p*3+k] * qRed(pixel);
                }
                sobel_norm[x+y*width] = abs(value_gx) + abs(value_gy);

                max=sobel_norm[x+y*width]>max ? sobel_norm[x+y*width]:max;
            }
        }
    }

    for(int i=0;i<width;i++){
        for(int j=0;j<height;j++){
            my_color.setHsv( 0 ,0, 255-int(255.0*sobel_norm[i + j * width]/max));
            newImage.setPixel(i,j,my_color.rgb());
        }
    }
    delete[] sobel_norm;
    return newImage;
}

QImage Tools::PrewittEdge(const QImage &origin)
{
    double *Gx = new double[9];
    double *Gy = new double[9];

    /* Sobel */
    Gx[0] = -1.0; Gx[1] = 0.0; Gx[2] = 1.0;
    Gx[3] = -1.0; Gx[4] = 0.0; Gx[5] = 1.0;
    Gx[6] = -1.0; Gx[7] = 0.0; Gx[8] = 1.0;

    Gy[0] = 1.0; Gy[1] = 1.0; Gy[2] = 1.0;
    Gy[3] = 0.0; Gy[4] = 0.0; Gy[5] = 0.0;
    Gy[6] = -1.0; Gy[7] = -1.0; Gy[8] = -1.0;

    QRgb pixel;
    QImage grayImage = GreyScale(origin);
    int height = grayImage.height();
    int width = grayImage.width();
    QImage newImage = QImage(width, height,QImage::Format_RGB888);

    //float sobel_norm[width*height];
	float *sobel_norm = new float[width * height];
    float max = 0.0;
    QColor my_color;

    for (int x=0; x<width; x++)
    {
        for( int y=0; y<height; y++)
        {
            double value_gx = 0.0;
            double value_gy = 0.0;

            for (int k=0; k<3;k++)
            {
                for(int p=0; p<3; p++)
                {
                    pixel=grayImage.pixel(x+1+1-k,y+1+1-p);
                    value_gx += Gx[p*3+k] * qRed(pixel);
                    value_gy += Gy[p*3+k] * qRed(pixel);
                }
//                sobel_norm[x+y*width] = sqrt(value_gx*value_gx + value_gy*value_gy)/1.0;
                sobel_norm[x+y*width] = abs(value_gx) + abs(value_gy);

                max=sobel_norm[x+y*width]>max ? sobel_norm[x+y*width]:max;
            }
        }
    }

    for(int i=0;i<width;i++){
        for(int j=0;j<height;j++){
            my_color.setHsv( 0 ,0, 255-int(255.0*sobel_norm[i + j * width]/max));
            newImage.setPixel(i,j,my_color.rgb());
        }
    }
    return newImage;
}




/*****************************************************************************
 *                                  高斯平滑
 * **************************************************************************/
QImage Tools::GaussianSmoothing(const QImage &origin, int radius, double sigma)      //这里已用单独的dialog_gaussianblur文件实现，可以直接调用
{

    GaussianBlur *blur = new GaussianBlur(radius, sigma);
    QImage newImage = blur->BlurImage(origin);

    return newImage;
}

/*****************************************************************************
 *                                 二值化
 * **************************************************************************/
QImage Tools::Binaryzation(const QImage &origin)
{


    int width = origin.width();
    int height = origin.height();
    QImage newImg = QImage(width, height, QImage::Format_RGB888);

    for (int x=0; x<width; x++)
    {
        for(int y=0; y<height; y++)
        {
            int gray = qGray(origin.pixel(x,y));
            int newGray;
            if (gray > 128)                  //阈值设定为128
                newGray = 255;
            else
                newGray = 0;
            newImg.setPixel(x,y,qRgb(newGray, newGray, newGray));
        }
    }
    return newImg;
}


/*****************************************************************************
 *                                 金属拉丝效果
 * **************************************************************************/
QImage Tools::Metal(QImage origin)
{
    QImage *baseImage = new QImage(":/img/src/metal.png");            //网上参考的，需要提前存一张金属图像
    QImage darkImage = Tools::Brightness(-100, origin);
    QImage greyImage = Tools::GreyScale(darkImage);
    QPainter painter;

    QImage newImage = baseImage->scaled(QSize(origin.width(),origin.height()));     //必须先使金属图像和原图像的尺寸相同

    painter.begin(&newImage);
    painter.setOpacity(0.5);        //这里是设置窗体透明度
    painter.drawImage(0, 0, greyImage);    //灰度化的图像和金属图像一起
    painter.end();

    return newImage;
}


/*****************************************************************************
 *                                 轮廓提取法
 * **************************************************************************/
QImage Tools::ContourExtraction(const QImage &origin)
{
    int width = origin.width();
    int height = origin.height();
    int pixel[8];   // 当前像素周围的8个像素的像素值
//    int *pixel = new int[9];
    QImage binImg = Binaryzation(origin);      //暂时存二值化的图像
    QImage newImg = QImage(width, height, QImage::Format_RGB888);
    newImg.fill(Qt::white);         //先以全白填充

    for(int y=1; y<height; y++)
    {
        for(int x=1; x<width; x++)
        {
            memset(pixel,0,8);     //C++<algorithm>的模板，先设定元素值

            if (QColor(binImg.pixel(x,y)).red() == 0)
            {
                newImg.setPixel(x, y, qRgb(0,0,0));                //先初始化全黑色
                pixel[0] = QColor(binImg.pixel(x-1,y-1)).red();     //给周围8个像素赋值红色，实现轮廓提取
                pixel[1] = QColor(binImg.pixel(x-1,y)).red();
                pixel[2] = QColor(binImg.pixel(x-1,y+1)).red();
                pixel[3] = QColor(binImg.pixel(x,y-1)).red();
                pixel[4] = QColor(binImg.pixel(x,y+1)).red();
                pixel[5] = QColor(binImg.pixel(x+1,y-1)).red();
                pixel[6] = QColor(binImg.pixel(x+1,y)).red();
                pixel[7] = QColor(binImg.pixel(x+1,y+1)).red();
                if (pixel[0]+pixel[1]+pixel[2]+pixel[3]+pixel[4]+pixel[5]+pixel[6]+pixel[7] == 0)
                    newImg.setPixel(x,y,qRgb(255,255,255));
            }
        }
    }

    return newImg;
}



/*****************************************************************************
 *                                 全方位腐蚀
 * **************************************************************************/
QImage Tools::Dilate(const QImage &origin){                                 //这里也是参照网上和老师给的代码
    int width = origin.width();
    int height = origin.height();
    QImage newImg = QImage(width, height, QImage::Format_RGB888);

    int dilateItem[9] = {1,0,1,
                         0,0,0,
                         1,0,1};

    for (int x=1; x<width-1; x++)
    {
        for(int y=1; y<height-1; y++)
        {
            newImg.setPixel(x,y,qRgb(0,0,0));
            for(int m=0; m<3; m++)
            {
                for(int n=0; n<3; n++)
                {
                    if(dilateItem[m+n] == 1)
                        continue;
                    QColor mColor = origin.pixel(x+(n-1),y+(1-m));
                    if(mColor.red() > 128){
                        newImg.setPixel(x,y,qRgb(255,255,255));
                    }
                }
            }
        }
    }
    return newImg;
}

/*****************************************************************************
 *                                 全方位膨胀
 * **************************************************************************/

QImage Tools::Expansion(const QImage &origin)
{
    int width = origin.width();
    int height = origin.height();
    QImage newImg = QImage(width, height, QImage::Format_RGB888);

    int dilateItem[9] = {1,0,1,
                         0,0,0,
                         1,0,1};

    for (int x=1; x<width-1; x++)
    {
        for(int y=1; y<height-1; y++)
        {
            newImg.setPixel(x,y,qRgb(255,255,255));
            for(int m=0; m<3; m++)
            {
                for(int n=0; n<3; n++)
                {
                    if(dilateItem[m+n] == 1)
                        continue;
                    QColor mColor = origin.pixel(x+(n-1),y+(1-m));
                    if(mColor.red() < 128){
                        newImg.setPixel(x,y,qRgb(0,0,0));
                    }
                }
            }
        }
    }
    return newImg;
}


/*****************************************************************************
 *                                开运算
 * **************************************************************************/
QImage Tools::Opening(const QImage &origin)                 //先腐蚀后膨胀
{
    QImage afterDilate = Dilate(origin);
    QImage afterExpansion = Expansion(afterDilate);

    return afterExpansion;
}

/*****************************************************************************
 *                                闭运算
 * **************************************************************************/
QImage Tools::Closing(const QImage &origin)                    //先膨胀后腐蚀
{
    QImage afterExpansion = Expansion(origin);
    QImage afterDilate = Dilate(afterExpansion);

    return afterDilate;
}


//QImage Tools::RGB2HSV(const QImage &origin)                                   //这里好像没调试成功！！
//{
//    int width = origin.width();
//    int height = origin.height();
//    QImage newImg = QImage(width, height, QImage::Format_RGB888);

//    for(int x=0; x<width; x++)
//    {
//        for(int y=0; y<height; y++)
//        {
//            QColor color = origin.pixel(x,y);
////            int hue = color.hue();
//            int hue = 0;
//            color.setHsv(hue, color.saturation(), color.value(), color.alpha());
////            newImg.setPixelColor(x,y,color);
//            newImg.setPixel(x,y,qRgb(color.red(),color.green(),color.blue()));
//        }
//    }
//    return newImg;
//}

//QImage Tools::RGB2HSL(const QImage &origin)
//{
//    int width = origin.width();
//    int height = origin.height();
//    QImage newImg = QImage(width, height, QImage::Format_RGB888);

//    for(int x=0; x<width; x++)
//    {
//        for(int y=0; y<height; y++)
//        {
//            QColor color = origin.pixel(x,y);
//            int h = 100;
//            color.setHsl(h, color.saturation(),color.lightness(), color.alpha());
//            newImg.setPixel(x,y,qRgb(color.red(),color.green(),color.blue()));
//        }
//    }
//    return newImg;
//}

//QImage Tools::RGB2CMYK(const QImage &origin)
//{
//    int width = origin.width();
//    int height = origin.height();
//    QImage newImg = QImage(width, height, QImage::Format_RGB888);

//    for(int x=0; x<width; x++)
//    {
//        for(int y=0; y<height; y++)
//        {
//            QColor color = origin.pixel(x,y);
//            int h = 100;
////            color.setCmyk(color.cyan(), color.magenta(), color.yellow(), color.black());
//            color.setCmyk(color.cyan(), color.magenta(), 0, color.black());
//            newImg.setPixel(x,y,qRgb(color.red(),color.green(),color.blue()));
//        }
//    }
//    return newImg;
//}


QImage Tools::Final(const QImage &origin)                    //综合几个图像操作后的结果，这里是全方位膨胀以及拉普拉斯锐化
{
    int width  = origin.width()/3;
    int height = origin.height()/3;
    int dilateItem[9] = {1,0,1,
                         0,0,0,
                         1,0,1};



    QImage newImg = QImage(origin.width(), origin.height(), QImage::Format_RGB888);

    for(int x=1; x<width; x++)
    {
        for(int y=1; y<height; y++)
        {
            newImg.setPixel(x,y,qRgb(255,255,255));
            for(int m=0; m<3; m++)
            {
                for(int n=0; n<3; n++)
                {
                    if(dilateItem[m+n] == 1)
                        continue;
                    QColor mColor = origin.pixel(x+(n-1),y+(1-m));
                    if(mColor.red() < 128){
                        newImg.setPixel(x,y,qRgb(0,0,0));
                    }
                }
            }
        }
    }


    // laplace
    int window[3][3] = {0,-1,0,-1,4,-1,0,-1,0};
    for(int x=width; x<2*width; x++)
    {
        for(int y=1; y<height; y++)
        {
            int sumR = 0;
            int sumG = 0;
            int sumB = 0;

            //对每一个像素使用模板
            for(int m=x-1; m<= x+1; m++)
                for(int n=y-1; n<=y+1; n++)
                {
                    if(m>=0 && m<width && n<height)
                    {
                        sumR += QColor(origin.pixel(m,n)).red()*window[n-y+1][m-x+1];
                        sumG += QColor(origin.pixel(m,n)).green()*window[n-y+1][m-x+1];
                        sumB += QColor(origin.pixel(m,n)).blue()*window[n-y+1][m-x+1];
                    }
                }


            int old_r = QColor(origin.pixel(x,y)).red();
            sumR += old_r;
            sumR = qBound(0, sumR, 255);

            int old_g = QColor(origin.pixel(x,y)).green();
            sumG += old_g;
            sumG = qBound(0, sumG, 255);

            int old_b = QColor(origin.pixel(x,y)).blue();
            sumB += old_b;
            sumB = qBound(0, sumB, 255);


            newImg.setPixel(x,y, qRgb(sumR, sumG, sumB));
        }
    }




    return newImg;
}
