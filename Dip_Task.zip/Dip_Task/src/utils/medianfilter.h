#ifndef MEDIANFILTER_H
#define MEDIANFILTER_H

#include <QObject>
#include <QtConcurrent>
#include <QProgressDialog>

typedef int element;
#define MAX_FILTER_RADIUS 30

struct IndexPair{              //结构体表示索引对
    int i, j;
    IndexPair(int a, int b)
    {
        i = a; j = b;
    }
};

class MedianFilter : public QObject
{
    Q_OBJECT
public:
    static MedianFilter *mfStatic;       //静态MedianFilter类指针
    explicit MedianFilter(QObject *parent = 0);      //构造函数
    ~MedianFilter();
    void applyMedianFilter(element *i, element *res, const int imageHeight, const int imageWidth, const int r);  //传指针类型，使得中值滤波后的图像直接存到res里
    void getResPixelValue(IndexPair &p);
public slots:
    void cancelMedianFilter();
private:
    element *image, *extensionImage, *resImage;
    int originImageweight, radius, windowSize, windowSizeHalf;
    QFutureWatcher<void> *futureWatcher;
    QProgressDialog *progressDialog;    
};

#endif // MEDIANFILTER_H
