#define _USE_MATH_DEFINES
#include "gaussianblur.h"
#include <math.h>
#include <algorithm>
#include <numeric>
#include <functional>


GaussianBlur::GaussianBlur(int blurRadius, double sigma) :
                    mBlurRadius(blurRadius),
                    mSigma(sigma)
{
    CreateConvolutionMatrix();
}

QImage GaussianBlur::BlurImage(const QImage& in)
{
    if(in.isNull())
        return QImage();

    QImage image(in.size(), in.format());         //初始化图像为QImage类型

    int matrixSize = mConvolutionMatrix.size();       //定义卷积矩阵的大小
    int halfMatrixSize = matrixSize / 2;          //卷积矩阵尺寸的一半

    float sumRed = 0.0f;             //R通道
    float sumBlue = 0.0f;            //B通道
    float sumGreen = 0.0f;           //G通道
    float matrixValue = 0.0f;
    int x1 = 0, y1 = 0;

    for (int x = 0; x < in.width(); ++x)
    {
        for (int y = 0; y < in.height(); ++y)
        {
            for (int kx = -halfMatrixSize; kx <= halfMatrixSize; ++kx)
            {
                x1 = ReflectIndex(x - kx, in.width());    //用于指定像素横坐标的镜像值，即处理左右边缘像素

                QColor color(in.pixel(x1, y));     //QColor构造函数基于RGB值创建颜色

                matrixValue = mConvolutionMatrix[kx + halfMatrixSize];    //卷积矩阵对应图像像素的值

                sumRed += color.red() * matrixValue;           //三通道分别用颜色值乘以权重
                sumBlue += color.blue() * matrixValue;
                sumGreen += color.green() * matrixValue;
            }

            QRgb finalColor = qRgb(sumRed, sumGreen, sumBlue);    //重新合并颜色通道
            image.setPixel(x, y, finalColor);         //图像重新赋值颜色

            sumRed = sumGreen = sumBlue = 0.0f;
        }
    }

    for (int x = 0; x < in.width(); ++x)
    {
        for (int y = 0; y < in.height(); ++y)
        {
            for (int ky = -halfMatrixSize; ky <= halfMatrixSize; ++ky)
            {
                y1 = ReflectIndex(y - ky, in.height());        //用于指定像素纵坐标的镜像值，即处理上下边缘像素

                QColor color(image.pixel(x, y1));                  //和上述过程类似，分别用图像三通道值乘上对应权重最后再合并
                matrixValue = mConvolutionMatrix[ky + halfMatrixSize];

                sumRed += color.red() * matrixValue;
                sumBlue += color.blue() * matrixValue;
                sumGreen += color.green() * matrixValue;
            }

            QRgb finalColor = qRgb(sumRed, sumGreen, sumBlue);
            image.setPixel(x, y, finalColor);

            sumRed = sumGreen = sumBlue = 0.0f;
        }
    }

    return image;
}

float GaussianBlur::GaussFunc(float x)               //这里定义高斯函数
{
    // Gaussian function in one dimension
    return (1 / sqrtf(2*M_PI * mSigma * mSigma)) *
            exp(-(x*x)/(2*mSigma*mSigma));
}

void GaussianBlur::CreateConvolutionMatrix()       //定义构造卷积矩阵的函数
{
    int x = 0;
    size_t matrixSize, halfMatrixSize;

    matrixSize = (size_t)(2*mBlurRadius + 1);     //卷积矩阵的大小等于2倍高斯半径加1
    halfMatrixSize = matrixSize / 2;              //卷积矩阵大小的一半

    mConvolutionMatrix.resize(matrixSize);

    vector<float>::iterator begin = mConvolutionMatrix.begin();     //用容器类型遍历卷积矩阵
    vector<float>::iterator end = mConvolutionMatrix.end();

    x = -(int)halfMatrixSize;     //从左半边填充部分开始
    std::for_each(begin, end,
                [&] (float& val) mutable
                {
                    val = GaussFunc(x);        //取得对应像素值高斯化后的值，这里用到了C++里STL<algorithm>的模板函数for_each，即每个被遍历的像素值均被高斯化
                    x++;
                });

    // 归一化卷积矩阵的值，高斯模糊必须让权重矩阵和为1
    float sum = std::accumulate(begin, end, 0.0f);

    std::for_each(begin, end, [&] (float& val) { val /= sum; });
}

int GaussianBlur::ReflectIndex(int x, int length)    //定义处理图像边缘的函数
{
    if (x < 0)
        return -x - 1;
    else if(x >= length)
        return 2*length - x - 1;

    return x;
}

float GaussianBlur::getSigma() const     //get函数,用于获取高斯函数中的sigma值
{
    return mSigma;
}

void GaussianBlur::setSigma(float value)    //set函数,用于设置高斯函数中的sigma值，用该值创建卷积矩阵
{
    mSigma = value;
    CreateConvolutionMatrix();
}

int GaussianBlur::getBlurRadius() const       //获取高斯模糊的半径，半径越大，模糊效果越明显，因为半径越大，中心元素取的周围元素的平均值越平滑
{
    return mBlurRadius;
}

void GaussianBlur::setBlurRadius(int value)   //设置高斯模糊的半径，并创建卷积矩阵
{
    mBlurRadius = value;
    CreateConvolutionMatrix();
}

GaussianBlur::~GaussianBlur()
{
}
