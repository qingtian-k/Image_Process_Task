/****************************************************************************
 *                              Basic tools:
 * greyscale, brightness, flip, wand or cool ...
 * *************************************************************************/

#ifndef TOOLS_H
#define TOOLS_H


#include <QPainter>
#include <QPixmap>
#include <QDebug>
#include <QPainter>
#include <QtMath>
#include "gaussianblur.h"

//声明一些功能函数，具体实现在源文件utils/tools.cpp里
namespace Tools {
QImage GreyScale(QImage origin);               //灰度化
QImage Warm(int delta, QImage origin);         //图像变暖
QImage Cool(int delta, QImage origin);         //图像变冷
QImage DrawFrame(QImage origin, QImage &frame);   //添加相框
QImage Brightness(int delta, QImage origin);     //增强亮度
QImage Horizontal(const QImage &origin);        //水平翻转
QImage Vertical(const QImage &origin);       //垂直翻转
QImage LinearLevelTransformation(const QImage &origin, double a, double b);    //线性灰度变换
QImage LogGreyLevelTransformation(const QImage &origin, double a, double b);    //对数灰度变换
QImage PowerGreyLevelTransformation(const QImage &origin, double c, double r, double b);  //幂次灰度变换
QImage ExpTransform(const QImage &origin, double b, double c, double a);      //指数灰度变换
QImage TwoThreshold(const QImage &orogin, double t1, double t2, int option);   //双阈值灰度变换
QImage StretchTransform(const QImage &origin,                            //拉伸灰度变换
                                        int x1, int x2,
                                        double k1, double k2, double k3,
                                        double b2, double b3);
QImage SimpleSmooth(const QImage &origin);                       //简单的平滑操作
QImage MeidaFilter(const QImage &origin, int radius);         //中值滤波
QImage LaplaceSharpen(const QImage &origin);                //拉普拉斯锐化
QImage SobelEdge(const QImage &origin);                     //Sobel边缘提取
QImage GaussianSmoothing(const QImage &origin, int radius, double sigma);   //高斯平滑
QImage Binaryzation(const QImage &origin);                 //二值化
QImage Metal(QImage origin);                               //金属
QImage PrewittEdge(const QImage &origin);                 //Prewitt算子提取边缘
QImage ContourExtraction(const QImage &origin);           //轮廓提取
QImage Dilate(const QImage &origin);                     //全方位腐蚀
QImage Expansion(const QImage &origin);                  //全方位膨胀
QImage Opening(const QImage &origin);                    //形态学开操作
QImage Closing(const QImage &origin);                   //形态学闭操作
QImage Thinning(const QImage &origin);
//QImage RGB2HSV(const QImage &origin);
//QImage RGB2HSL(const QImage &origin);
//QImage RGB2CMYK(const QImage &origin);
QImage Final(const QImage &origin);                 //全方位膨胀+拉普拉斯锐化
}




#endif // TOOLS_H
