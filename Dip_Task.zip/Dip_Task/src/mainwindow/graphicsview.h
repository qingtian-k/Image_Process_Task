#ifndef GRAPHICSVIEW_H
#define GRAPHICSVIEW_H

#include <QGraphicsView>
#include <QWheelEvent>
#include <QtMath>

//画整个界面的类，用来调节显示的图像大小，私有变量factor定义缩放的因子

class GraphicsView : public QGraphicsView
{
private:
    int factor;

public:
    GraphicsView(QWidget* parent = nullptr);
    ~GraphicsView();

    int getFactor();
    void setFactor(int _factor);

protected:
    virtual void wheelEvent(QWheelEvent *e);    //鼠标滑轮改变图像大小
};

#endif // GRAPHICSVIEW_H
